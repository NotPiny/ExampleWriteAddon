# Write Example Addon - Resource Pack
This resource pack demonstrates how to create and display custom block and item models in Minecraft 26.2. (May work on versions before, hopefully will work after, tested on 26.2.)

## Directory Structure

```
ResourcePack/
└── assets/
    └── example/                           # Custom content
        ├── items/
        │   ├── block/
        │   │   ├── example_block.json     # Item definition (everything uses item_model so we need something here to guide it to the model)
        │   │   └── example_block_head.json
        │   ├── example_item.json
        │   └── write_icon.json
        ├── models/
        │   ├── item/
        │   │   ├── example_item.json
        │   │   └── write_icon.json
        │   └── block/
        │       ├── example_block.json     # "particle" texture will NOT work, particle is controlled by baseMaterial.
        │       └── example_block_head.json
        ├── textures/
        │   ├── item/
        │   │   ├── example_item.png
        │   │   └── write_icon.png
        │   └── block/
        │       ├── example_block.png
        │       ├── example_block_head.png
        │       └── example_block_top.png
        └── lang/
            └── en_us.json                 # Translations (for custom names although this can be avoided in code by specifying a name)
```

You should probably read [the docs](https://docs.piny.dev/write).
